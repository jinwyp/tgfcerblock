# Block Tgfcer User's post chrome extensions

## Block user's post for tgfcer forum

### 用于屏蔽某些用户的发帖，不显示或隐藏

## 使用方法 Usage

1. 解压zip文件到任意文件夹
2. 打开chrome 浏览器 输入chrome://extensions/ 或 通过菜单进入扩展程序页面
3. 点击右上角开启开发者模式, 然后点击左上的 "加载已解压的扩展程序" 按钮 选择之前解压的文件夹即可
4. 进入该插件设置 可以添加需要屏蔽的用户


